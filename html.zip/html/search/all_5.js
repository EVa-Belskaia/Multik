var searchData=
[
  ['planetrotates_11',['PlanetRotates',['../BelskaiaEvgeniia_8h.html#a8e8bf8f87793e85f056825560c708384',1,'BelskaiaEvgeniia.h']]]
];
