var indexSectionsWithContent =
{
  0: "bcdgprt",
  1: "b",
  2: "bcdgprt"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Файлы",
  2: "Функции"
};

