var indexSectionsWithContent =
{
  0: "bcdglprt",
  1: "b",
  2: "bcdglprt"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Файлы",
  2: "Функции"
};

