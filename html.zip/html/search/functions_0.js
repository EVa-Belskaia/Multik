var searchData=
[
  ['background_15',['BackGround',['../BelskaiaEvgeniia_8h.html#af060f6dce909e478dfce46f3e678f9ba',1,'BelskaiaEvgeniia.h']]]
];
