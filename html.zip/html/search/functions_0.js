var searchData=
[
  ['background_17',['BackGround',['../BelskaiaEvgeniia_8h.html#af060f6dce909e478dfce46f3e678f9ba',1,'BelskaiaEvgeniia.h']]],
  ['bang_18',['Bang',['../BelskaiaEvgeniia_8h.html#af70b9bc678810ac2a21006b3eeb646fe',1,'BelskaiaEvgeniia.h']]]
];
